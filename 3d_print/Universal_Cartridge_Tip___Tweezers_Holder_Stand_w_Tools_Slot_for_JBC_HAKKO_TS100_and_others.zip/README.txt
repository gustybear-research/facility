                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2881417
Universal Cartridge Tip & Tweezers Holder Stand w/Tools Slot for JBC, HAKKO, TS100 and others by sn4k3 is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

For ERSA or normal tip stand please look here: https://www.thingiverse.com/thing:2406919

I don't like the oval T12 tip holder, thats messy and don't have a good pattern IMO. Matrix organization is much easier to remember and give a meaning to rows and columns. With that in mind i have remixed my ERSA stand and create this. As i have many tips from T12, TS100, and others, 70 slots is the way to go and fill that space!

**Versions**
**Normal:** 70 x Tip slots for cartridges (6.2x27mm)
**Tolerance:** 40 x Tip slots for cartridges (6.5x27mm) with matrix numbers and more space between tips (15mm instead of 12mm), can also be used for ABS print

**Features**
* 1 x Vacuum Desolder Slot (12x27mm)
* 18 x Tweezers Slots (12x5.5x30mm)
* 2 x Tweezers Like Slots for other tools (5.5x12x30mm)
* 70 x Tip slots for cartridges (6x27mm) OR * 40 x Tip slots for cartridges (6.5x27mm)
* 4 x Bottom rubber pads (10mm)

**Tips Compability List:**

1. Hakko T12/T15 Cartridges
2. TS100 Cartridges
2. JBC C105 Cartridges
4. All others cartridges and tips under 6mm body diameter

With this you can organize all yours tips in a good way.
Group rows or cols with tip type, example:
Row1: Oval tips
Row2: Chissel
Row3: Knife
Row4: ...

# Print Settings

Printer Brand: Prusa
Printer: i3 MK3
Rafts: No
Supports: No
Resolution: 0.30mm
Infill: 15%

Notes: 
Print this with the fastest method you can, this will take time (>10 hours) and don't need fine detail.
PETG or ABS if you want the best duration, but PLA will do just fine, and you can insert tip while hot, the heat will not reach the plastic, only 27mm of the tip will sit inside the holder.